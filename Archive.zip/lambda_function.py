import json

# Download the helper library from https://www.twilio.com/docs/python/install
from twilio.rest import Client



def lambda_handler(event, context):
    # TODO implement
    toNumber = event['to']
    
    message = '''New Relic Alert for account {}: 
        Policy: {}
        Condition: {}
        Incident: {}
        Targets: {}
        '''.format(event['account_id'], event['policy_name'], event['condition_name'], event['incident_url'], event['targets'])
        
    
    # Your Account Sid and Auth Token from twilio.com/console
    account_sid = 'ACcba50b2642ab518936e3a5d45699f586'
    auth_token = 'your_auth_token'
    client = Client(account_sid, auth_token)
    
    toNumber = 'whatsapp:{}'.format(toNumber)
    message = client.messages.create(
                                  body=message,
                                  from_='whatsapp:+14155238886',
                                  to=toNumber
                              )
    print(message.sid)
    
    return {
        'statusCode': 200,
        'body': json.dumps('Whatsapp from Lambda!')
    }
